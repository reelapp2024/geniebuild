import React, { useState } from 'react';
import { Section, WebsiteElement } from '../types';
import { SectionRouter } from './sections/SectionRouter';
import { useTheme } from '@ui/blocks';
import { DEFAULT_TYPOGRAPHY, PRESET_THEMES } from '../constants';

interface SectionRendererProps {
  section: Section;
  onUpdate: (id: string, updates: Partial<Section>) => void;
  isSelected: boolean;
  readOnly?: boolean;
  onClick: () => void;
  onDelete: (id: string) => void;
  onMoveUp: (id: string) => void;
  onMoveDown: (id: string) => void;
  onUpload?: (sectionId: string, field: string) => void;
  onElementSelect?: (elementId: string, element?: WebsiteElement) => void;
  selectedElementId?: string | null;
}

const BackgroundCarousel: React.FC<{
  images: Array<{ url: string; id: string }>;
  settings: any;
  styles: any;
}> = ({ images, settings, styles }) => {
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [isHovered, setIsHovered] = React.useState(false);

  React.useEffect(() => {
    if (!settings.enabled || !settings.autoplay || images.length <= 1) return;
    if (settings.pauseOnHover && isHovered) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, settings.duration || 5000);
    return () => clearInterval(interval);
  }, [settings.enabled, settings.autoplay, settings.duration, images.length, settings.pauseOnHover, isHovered]);

  if (!images || images.length === 0) return null;

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const transitionStyle = settings.transitionType === 'fade' 
    ? { transition: `opacity ${settings.transitionSpeed || 500}ms ease-in-out` }
    : { transition: `transform ${settings.transitionSpeed || 500}ms ease-in-out` };

  const buttonVariant = settings.buttonVariant || 'minimal';

  const renderButtons = () => {
    if (buttonVariant === 'hidden' || images.length <= 1) return null;

    let btnClass = "absolute top-1/2 -translate-y-1/2 z-20 flex items-center justify-center cursor-pointer transition-all ";
    
    switch (buttonVariant) {
      case 'rounded':
        btnClass += "w-12 h-12 rounded-full bg-black/50 text-white hover:bg-black/70 backdrop-blur-sm";
        break;
      case 'square':
        btnClass += "w-12 h-12 bg-black/50 text-white hover:bg-black/70 backdrop-blur-sm";
        break;
      case 'outline':
        btnClass += "w-12 h-12 rounded-full border-2 border-white text-white hover:bg-white/20 backdrop-blur-sm";
        break;
      case 'minimal':
      default:
        btnClass += "w-10 h-10 text-white/70 hover:text-white drop-shadow-md";
        break;
    }

    return (
      <>
        <div className={`${btnClass} left-4`} onClick={handlePrev}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        </div>
        <div className={`${btnClass} right-4`} onClick={handleNext}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
        </div>
      </>
    );
  };

  return (
    <div 
      className="absolute inset-0 z-0 overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {settings.transitionType === 'slide' ? (
        <div 
          className="absolute inset-0 flex h-full w-full"
          style={{ 
            ...transitionStyle,
            transform: `translateX(-${currentIndex * 100}%)` 
          }}
        >
          {images.map((img) => (
            <div 
              key={img.id}
              className="w-full h-full flex-shrink-0 bg-cover bg-center bg-no-repeat"
              style={{ 
                backgroundImage: `url(${img.url})`,
                backgroundPosition: styles.background?.image?.position || styles.backgroundPosition || 'center',
                backgroundSize: styles.background?.image?.size || styles.backgroundSize || 'cover',
                backgroundRepeat: styles.background?.image?.repeat || styles.backgroundRepeat || 'no-repeat',
              }}
            />
          ))}
        </div>
      ) : (
        images.map((img, idx) => (
          <div 
            key={img.id}
            className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat"
            style={{ 
              backgroundImage: `url(${img.url})`,
              opacity: currentIndex === idx ? 1 : 0,
              backgroundPosition: styles.background?.image?.position || styles.backgroundPosition || 'center',
              backgroundSize: styles.background?.image?.size || styles.backgroundSize || 'cover',
              backgroundRepeat: styles.background?.image?.repeat || styles.backgroundRepeat || 'no-repeat',
              ...transitionStyle
            }}
          />
        ))
      )}
      {renderButtons()}
    </div>
  );
};

const SectionRenderer: React.FC<SectionRendererProps> = ({ 
  section, 
  onUpdate, 
  isSelected, 
  readOnly = false,
  onClick, 
  onDelete,
  onMoveUp,
  onMoveDown,
  onUpload,
  onElementSelect,
  selectedElementId
}) => {
  const { type, content, styles } = section;
  const { themeData } = useTheme();

  const handleTextEdit = (key: keyof typeof content, value: string) => {
    if (readOnly) return;
    onUpdate(section.id, {
      content: { ...content, [key]: value }
    });
  };

  const handleItemEdit = (itemId: string, updates: any) => {
    if (readOnly) return;
    const newItems = content.items?.map(item => 
      item.id === itemId ? { ...item, ...updates } : item
    );
    onUpdate(section.id, { content: { ...content, items: newItems } });
  };

  const handleElementUpdate = (elementId: string, updates: Partial<WebsiteElement>) => {
    if (readOnly) return;
    const newElements = section.elements?.map(el => 
        el.id === elementId ? { ...el, ...updates } : el
    );
    onUpdate(section.id, { elements: newElements });
  };

  const handleLinkEdit = (index: number, newLabel: string) => {
    if (readOnly) return;
    const links = content.links || [];
    const newLinks = [...links];
    if(newLinks[index]) {
        newLinks[index] = { ...newLinks[index], label: newLabel };
        onUpdate(section.id, { content: { ...content, links: newLinks } });
    }
  };

  const addItem = () => {
    if (readOnly) return;
    const newItem = {
      id: `item-${Date.now()}`,
      title: 'New Item',
      description: 'Add a description here.',
      icon: '✨',
      price: '$29',
      features: ['Feature 1', 'Feature 2'],
      author: 'Name',
      role: 'Role',
      avatar: 'https://i.pravatar.cc/150'
    };
    onUpdate(section.id, { content: { ...content, items: [...(content.items || []), newItem] } });
  };

  const removeItem = (id: string) => {
    if (readOnly) return;
    onUpdate(section.id, { content: { ...content, items: content.items?.filter(i => i.id !== id) } });
  };

  const handleImageClick = () => {
    if (readOnly) return;
    if (onUpload) {
        onUpload(section.id, 'imageUrl');
    } else {
        const newUrl = prompt('Enter image URL:', content.imageUrl || '');
        if (newUrl !== null) {
          handleTextEdit('imageUrl', newUrl);
        }
    }
  };
  
  const handleLogoClick = () => {
    if (readOnly) return;
    if (onUpload) {
        onUpload(section.id, 'logoImageUrl');
    } else {
        const newUrl = prompt('Enter Logo URL:', content.logoImageUrl || '');
        if (newUrl !== null) {
          handleTextEdit('logoImageUrl', newUrl);
        }
    }
  };

  const isTailwindClass = (val?: string) => {
    if (!val) return false;
    const prefixes = ['text-', 'pt-', 'pb-', 'pl-', 'pr-', 'px-', 'py-', 'mt-', 'mb-', 'ml-', 'mr-', 'mx-', 'my-', 'bg-', 'font-', 'rounded-', 'shadow-', 'border-'];
    return prefixes.some(p => val.startsWith(p)) && !val.includes('px') && !val.includes('rem') && !val.includes('%');
  };
  
  const isCustomColor = (value?: string) => value && (value.startsWith('#') || value.startsWith('rgb') || value.startsWith('hsl'));

  // 1. Resolve Colors - Fallback to global theme (Respecting Light/Dark mode requests)
  const isLight = styles.themeMode === 'light';
  const activeGlobalTheme = (themeData as any)?.elements || themeData || PRESET_THEMES[0].elements;
  const activeTypography =
    (themeData as any)?.typography ||
    (PRESET_THEMES[0] as any)?.typography ||
    DEFAULT_TYPOGRAPHY;

  // Typography font families (active by hierarchy: section styles -> global theme)
  const resolvedTitleFontFamily =
    styles.titleFontFamily ||
    styles.fontFamily ||
    activeTypography?.h1?.fontFamily;

  const resolvedSubtitleFontFamily =
    styles.subtitleFontFamily ||
    styles.fontFamily ||
    activeTypography?.h2?.fontFamily;

  const resolvedDescriptionFontFamily =
    styles.descriptionFontFamily ||
    styles.fontFamily ||
    activeTypography?.p?.fontFamily;

  const resolvedButtonFontFamily =
    styles.buttonFontFamily ||
    styles.fontFamily ||
    activeTypography?.button?.fontFamily;
  
  const defaultBg = isLight && activeGlobalTheme.light ? activeGlobalTheme.light.surface : (themeData?.surface || '#0E1214');
  const defaultTitle = isLight && activeGlobalTheme.light ? activeGlobalTheme.light.heading : (themeData?.heading || '#F8FAFC');
  const defaultText = isLight && activeGlobalTheme.light ? activeGlobalTheme.light.description : (themeData?.description || '#C7CDD6');

  const themeColors = {
      backgroundColor: styles.backgroundColor || defaultBg,
      textColor: styles.textColor || defaultText,
      titleColor: styles.titleColor || defaultTitle,
      subtitleColor: styles.subtitleColor || defaultText,
      accentColor: styles.accentColor || themeData?.accent || '#F59E0B',
      buttonBackgroundColor: styles.buttonBackgroundColor || themeData?.primaryButton?.bg || '#E11D48',
      buttonTextColor: styles.buttonTextColor || themeData?.primaryButton?.text || '#FFFFFF',
      borderColor: styles.borderColor || themeData?.ring || '#F43F5E',
      // Typography font families (used by hero components + ElementsSection)
      titleFontFamily: resolvedTitleFontFamily,
      subtitleFontFamily: resolvedSubtitleFontFamily,
      descriptionFontFamily: resolvedDescriptionFontFamily,
      buttonFontFamily: resolvedButtonFontFamily,
  };

  const getBackgroundStyles = (): React.CSSProperties => {
    const bgStyles: React.CSSProperties = {};
    
    if (styles.background) {
      if (styles.background.type === 'color') {
        bgStyles.backgroundColor = styles.background.color || styles.backgroundColor || themeData?.surface || '#000000';
      } else if (styles.background.type === 'gradient') {
        const gradient = styles.background.gradient;
        if (gradient) {
          const stops = gradient.stops.map((stop: any) => `${stop.color} ${stop.position}%`).join(', ');
          if (gradient.type === 'linear') {
            bgStyles.backgroundImage = `linear-gradient(${gradient.direction || 90}deg, ${stops})`;
          } else {
            bgStyles.backgroundImage = `radial-gradient(circle, ${stops})`;
          }
        }
      } else if (styles.background.type === 'image') {
        const imgConfig = styles.background.image || {};
        const isCarousel =
          imgConfig.mode === 'multiple' &&
          imgConfig.carouselSettings?.enabled &&
          Array.isArray(imgConfig.images) &&
          imgConfig.images.length > 0;
        
        if (!isCarousel && imgConfig.url) {
          bgStyles.backgroundImage = `url(${imgConfig.url})`;
          bgStyles.backgroundPosition = imgConfig.position || styles.backgroundPosition || 'center';
          bgStyles.backgroundSize = imgConfig.size || styles.backgroundSize || 'cover';
          bgStyles.backgroundRepeat = imgConfig.repeat || styles.backgroundRepeat || 'no-repeat';
          bgStyles.backgroundAttachment = imgConfig.attachment || styles.backgroundAttachment || 'scroll';
        } else if (!isCarousel && styles.backgroundImage) {
          // Backward-compat fallback for legacy sections that only stored backgroundImage
          bgStyles.backgroundImage = `url(${styles.backgroundImage})`;
          bgStyles.backgroundPosition = styles.backgroundPosition || 'center';
          bgStyles.backgroundSize = styles.backgroundSize || 'cover';
          bgStyles.backgroundRepeat = styles.backgroundRepeat || 'no-repeat';
          bgStyles.backgroundAttachment = styles.backgroundAttachment || 'scroll';
        }
      }
    } else {
      if (styles.backgroundImage) {
        bgStyles.backgroundImage = `url(${styles.backgroundImage})`;
        bgStyles.backgroundSize = 'cover';
        bgStyles.backgroundPosition = 'center';
      }
      if (isCustomColor(styles.backgroundColor)) {
        bgStyles.backgroundColor = styles.backgroundColor;
      } else {
        // Fall back to theme surface color if no background is set (including empty string, null, undefined)
        const hasBackground = styles.backgroundColor && styles.backgroundColor.trim() !== '';
        if (!hasBackground && themeData?.surface) {
          bgStyles.backgroundColor = themeData.surface;
        } else if (hasBackground && !isCustomColor(styles.backgroundColor)) {
          // Keep Tailwind class-based backgrounds
          bgStyles.backgroundColor = undefined;
        }
      }
    }
    
    // ALWAYS set surface color as fallback (like website multicolor theme does)
    if (!bgStyles.backgroundColor && themeData?.surface) {
      bgStyles.backgroundColor = themeData.surface;
    }
    
    return bgStyles;
  };

  const isFullBleed = styles.variant?.includes('Modern') || 
                     styles.variant?.includes('Geometric') || 
                     styles.variant?.includes('CrimsonJet') || 
                     styles.variant?.includes('Multicolor') || 
                     styles.variant?.includes('Gradient') ||
                     styles.variant?.includes('Explore') ||
                     styles.variant?.includes('Marquee');

  const inlineStyles: React.CSSProperties = {
    ...getBackgroundStyles(),
    ...(isCustomColor(styles.textColor) ? { color: styles.textColor } : { color: themeData?.description }),
    ...(!isTailwindClass(styles.marginTop) ? { marginTop: styles.marginTop } : {}),
    ...(!isTailwindClass(styles.marginBottom) ? { marginBottom: styles.marginBottom } : {}),
    ...(!isTailwindClass(styles.marginLeft) ? { marginLeft: styles.marginLeft } : {}),
    ...(!isTailwindClass(styles.marginRight) ? { marginRight: styles.marginRight } : {}),
    ...(!isFullBleed && !isTailwindClass(styles.paddingTop) ? { paddingTop: styles.paddingTop } : {}),
    ...(!isFullBleed && !isTailwindClass(styles.paddingBottom) ? { paddingBottom: styles.paddingBottom } : {}),
    ...(!isFullBleed && !isTailwindClass(styles.paddingLeft) ? { paddingLeft: styles.paddingLeft } : {}),
    ...(!isFullBleed && !isTailwindClass(styles.paddingRight) ? { paddingRight: styles.paddingRight } : {}),
  };

  const bgClass = !styles.background && !isCustomColor(styles.backgroundColor) ? styles.backgroundColor : '';
  const textClass = !isCustomColor(styles.textColor) ? styles.textColor : '';
  
  const spacingClasses = [
      !isFullBleed && isTailwindClass(styles.paddingTop) ? styles.paddingTop : '',
      !isFullBleed && isTailwindClass(styles.paddingBottom) ? styles.paddingBottom : '',
      !isFullBleed && isTailwindClass(styles.paddingLeft) ? styles.paddingLeft : '',
      !isFullBleed && isTailwindClass(styles.paddingRight) ? styles.paddingRight : '',
      isTailwindClass(styles.marginTop) ? styles.marginTop : '',
      isTailwindClass(styles.marginBottom) ? styles.marginBottom : '',
      isTailwindClass(styles.marginLeft) ? styles.marginLeft : '',
      isTailwindClass(styles.marginRight) ? styles.marginRight : ''
  ].filter(Boolean).join(' ');
  
  const containerClass = `relative group transition-all duration-300 ${bgClass} ${textClass} ${spacingClasses} ${!readOnly && isSelected ? 'ring-2 ring-white ring-offset-2 ring-offset-black z-10 shadow-[0_0_30px_rgba(255,255,255,0.1)]' : (!readOnly ? 'hover:ring-1 hover:ring-white/20 cursor-pointer' : '')}`;

  const formatColorClass = (prefix: string, val?: string) => {
    if (!val) return '';
    if (val.startsWith('#') || val.startsWith('rgb')) return `${prefix}-[${val}]`;
    return val;
  };

  const btnBg = formatColorClass('bg', styles.buttonBackgroundColor) || 'bg-white';
  const btnText = formatColorClass('text', styles.buttonTextColor) || 'text-black';

  const buttonBase = `${btnBg} ${btnText} px-6 py-2 transition-all hover:opacity-90 active:scale-95 shadow-lg shadow-current/20`;
  
  let borderRadius = 'rounded-lg';
  if (styles.borderRadius) {
      borderRadius = styles.borderRadius; 
  } else if (styles.buttonStyle === 'pill') {
      borderRadius = 'rounded-full';
  } else if (styles.buttonStyle === 'square') {
      borderRadius = 'rounded-none';
  }

  const buttonClass = `${buttonBase} ${borderRadius}`;
  
  const hasCustomSize = styles.titleSize && (styles.titleSize.includes('px') || styles.titleSize.includes('rem') || styles.titleSize.includes('em'));
  const titleClass = `font-bold mb-6 ${!isCustomColor(styles.titleColor) ? styles.titleColor || '' : ''}`;
  const titleStyle = {
    ...(isCustomColor(styles.titleColor) ? { color: styles.titleColor } : {}),
    ...(hasCustomSize ? { fontSize: styles.titleSize } : {})
  };

  const isFixedSection = type === 'navbar' || type === 'footer';

  // MATCH WEBSITE MULTICOLOR THEME: Two-layer overlay system (gradient + solid color)
  const getOverlayStyles = (): { 
    gradientOverlay: React.CSSProperties | null, 
    colorOverlay: React.CSSProperties | null 
  } => {
    
    // 1. Primary Source: Unified Background Object
    const bgOverlay = (styles.background?.type === 'image' 
      ? styles.background?.image?.overlay 
      : styles.background?.overlay) || styles.background?.overlay || styles.background?.image?.overlay;
    
    // 2. Secondary Source: Legacy Flat Properties
    const legacyColor = styles.overlayColor;
    const legacyOpacity = styles.overlayOpacityValue !== undefined ? styles.overlayOpacityValue : styles.overlayOpacity;
    const legacyBlend = styles.overlayBlendMode;
    
    // 3. Determine original color to check for ghost states FIRST
    const originalColor = bgOverlay?.color || legacyColor;
    let overlayColor = originalColor;
    const isGhostColor = !originalColor || originalColor === 'transparent' || originalColor === '#000000' || originalColor.replace(/\s/g, '') === 'rgba(0,0,0,0)' || originalColor.includes(', 0)');
    
    const activeThemeColor = (themeData as any)?.elements?.overlay?.color || (themeData as any)?.overlay?.color || PRESET_THEMES[0].elements.overlay.color;
    
    // If the saved DB color exactly matches the theme, it's a legacy theme save. We treat it like a ghost color to ensure it stays fully synced and visually enabled.
    const isThemeMatch = originalColor && originalColor.toLowerCase() === activeThemeColor.toLowerCase();
    const requiresResurrection = isGhostColor || isThemeMatch;

    // 4. Exit early if explicitly disabled, BUT ONLY if it is a truly custom user override (Resurrect broken saves)
    if (bgOverlay && bgOverlay.enabled === false && !requiresResurrection) {
      return { gradientOverlay: null, colorOverlay: null };
    }
    
    // Auto-fix broken transparent colors OR legacy pure black (#000000) from old database saves
    if (isGhostColor) {
        // Attempt to use Active Theme first, then strictly fallback to Crimson Jet
        const activeThemeColor = (themeData as any)?.elements?.overlay?.color || (themeData as any)?.overlay?.color;
        overlayColor = activeThemeColor || PRESET_THEMES[0].elements.overlay.color;
    }
    
    const blendMode = bgOverlay?.blendMode || legacyBlend || themeData?.overlay?.blend || PRESET_THEMES[0].elements.overlay.blend;
    
    // 5. Calculate correct Opacity
    let rawOpacityStr = bgOverlay?.opacity !== undefined ? bgOverlay.opacity : (legacyOpacity !== undefined ? legacyOpacity : (themeData?.overlay as any)?.opacity);
    let finalOpacity: number | undefined = PRESET_THEMES[0].elements.overlay.opacity; 
    
    // If we intercepted a broken color, we MUST intercept the opacity as well to prevent legacy 0.5 from overriding the theme's perfect glass opacity
    if (isGhostColor) {
        rawOpacityStr = (themeData as any)?.elements?.overlay?.opacity ?? (themeData as any)?.overlay?.opacity ?? PRESET_THEMES[0].elements.overlay.opacity;
    }

    if (rawOpacityStr !== undefined && rawOpacityStr !== '') {
      const parsedOpacity = typeof rawOpacityStr === 'string' ? parseFloat(rawOpacityStr) : rawOpacityStr;
      finalOpacity = parsedOpacity > 1 ? parsedOpacity / 100 : parsedOpacity;
    }
    
    // Layer 1: Gradient overlay (Removed: Was causing a double-dimming bug by forcing 100% opacity gradients over all images)
    const gradientOverlay = null;
    
    // Layer 2: Solid color overlay
    let finalBackgroundColor = overlayColor;
    // Strip rgba alpha if we are explicitly controlling it via CSS opacity to avoid double-dimming
    if (finalOpacity !== undefined && finalBackgroundColor.includes('rgba')) {
      finalBackgroundColor = finalBackgroundColor.replace(/rgba\((.*?),\s*[\d.]+\)/, 'rgb($1)');
    }

    const colorOverlay: React.CSSProperties = {
      backgroundColor: finalBackgroundColor,
      mixBlendMode: blendMode as any, // CRITICAL: Ensure blend mode applies to the color layer
      position: 'absolute' as const,
      inset: 0,
      zIndex: 0,
      pointerEvents: 'none' as const
    };

    // CRITICAL: Apply explicit opacity if the user set one in the builder
    if (finalOpacity !== undefined) {
      colorOverlay.opacity = finalOpacity;
    }
    
    return { gradientOverlay, colorOverlay };
  };

  const overlays = getOverlayStyles();

  const renderContent = () => {
    return (
      <SectionRouter
        section={section}
        onTextEdit={handleTextEdit}
        onImageClick={handleImageClick}
        onLinkEdit={handleLinkEdit}
        onLogoClick={handleLogoClick}
        onItemEdit={handleItemEdit}
        onAddItem={addItem}
        onRemoveItem={removeItem}
        onUpload={onUpload}
        onElementUpdate={handleElementUpdate}
        onElementSelect={onElementSelect}
        selectedElementId={selectedElementId}
        buttonClass={buttonClass}
        isSelected={isSelected}
        titleClass={titleClass}
        titleStyle={titleStyle}
        themeColors={themeColors}
        readOnly={readOnly}
      />
    );
  };

  const enableGeometry = styles.enableGeometry !== undefined ? styles.enableGeometry : (styles.variant === 'HeroGeometric');
  
  const isCarousel = styles.background?.type === 'image' && 
                     styles.background.image?.mode === 'multiple' && 
                     styles.background.image?.carouselSettings?.enabled && 
                     styles.background.image?.images && 
                     styles.background.image.images.length > 0;

  return (
    <div className={containerClass} style={inlineStyles} onClick={(e) => { if(!readOnly) { e.stopPropagation(); onClick(); }}}>
      {/* Background Carousel */}
      {isCarousel && (
        <BackgroundCarousel 
          images={styles.background!.image!.images!} 
          settings={styles.background!.image!.carouselSettings} 
          styles={styles} 
        />
      )}

      {/* Background overlay - Layer 1: Gradient (like website multicolor theme) */}
      {overlays.gradientOverlay && (
        <div 
          className="absolute inset-0 z-0 pointer-events-none" 
          style={overlays.gradientOverlay}
        ></div>
      )}
      
      {/* Background overlay - Layer 2: Solid Color (like website multicolor theme) */}
      {overlays.colorOverlay && (
        <div 
          className="absolute inset-0 z-0 pointer-events-none" 
          style={overlays.colorOverlay}
        ></div>
      )}
      
      {/* Geometry overlay */}
      {enableGeometry && (
        <div className="absolute inset-0 z-0 pointer-events-none">
          <div className="absolute inset-0 opacity-[0.03]" 
               style={{ backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`, backgroundSize: '50px 50px' }} />
        </div>
      )}
      
      {isSelected && !readOnly && (
        <div className="absolute top-4 right-4 z-50 flex items-center space-x-2 bg-black/90 backdrop-blur-md p-1.5 rounded-lg shadow-2xl border border-white/10 font-sans">
            <div className="px-3 text-[10px] font-black uppercase tracking-widest text-white">Section {type}</div>
            
            {!isFixedSection && (
                <>
                <button onClick={(e) => { e.stopPropagation(); onMoveUp(section.id); }} className="p-2 hover:bg-white/10 rounded-md text-slate-400 hover:text-white transition-colors" title="Move Up">
                <i className="fa-solid fa-arrow-up text-xs"></i>
                </button>
                <button onClick={(e) => { e.stopPropagation(); onMoveDown(section.id); }} className="p-2 hover:bg-white/10 rounded-md text-slate-400 hover:text-white transition-colors" title="Move Down">
                <i className="fa-solid fa-arrow-down text-xs"></i>
                </button>
                </>
            )}

            <div className="w-px h-6 bg-white/20 mx-1"></div>

            <button 
              onClick={(e) => { e.stopPropagation(); onDelete(section.id); }}
              className="bg-red-500/10 text-red-500 p-2 rounded-md hover:bg-red-500 hover:text-white transition-all" 
              title="Delete Section"
            >
               <i className="fa-solid fa-trash-can text-xs"></i>
            </button>
        </div>
      )}
      
      {/* Ensure content sits above the background and overlays */}
      <div className="relative z-10 w-full h-full">
        {renderContent()}
      </div>
    </div>
  );
};

export default SectionRenderer;