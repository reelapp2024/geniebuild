
import React from 'react';
import { Section, WebsiteElement } from '../../../types';
import { ElementsSection } from '../ElementsSection';

interface FAQLightProps {
  section: Section;
  isSelected?: boolean;
  onTextEdit: (key: any, value: string) => void;
  onElementSelect?: (elementId: string, element?: WebsiteElement) => void;
  onElementUpdate?: (elementId: string, updates: any) => void;
  selectedElementId?: string | null;
  readOnly?: boolean;
}

export const FAQLight: React.FC<FAQLightProps> = ({
  section,
  onTextEdit,
  onElementSelect,
  onElementUpdate,
  selectedElementId,
  readOnly = false,
}) => {
  const { content, styles } = section;
  const styleAny = styles as any;
  
  // Theme colors for global fallback inheritance
  const themeColors = {
    ...styles,
    fontWeight: styleAny.fontWeight,
    fontSize: styleAny.fontSize,
    textAlign: styles.textAlign || 'center',
    fontFamily: styleAny.fontFamily,
  };

  // Professional dry helper for hydrated elements
  const getEl = (idSuffix: string, fallbackType: any, fallbackContent: any, fallbackStyle: any): WebsiteElement => {
    const fullId = `${section.id}-faq-${idSuffix}`;
    const existingElement = section.elements?.find(e => e.id === fullId);
    if (existingElement) return existingElement;
    
    return { id: fullId, type: fallbackType, content: fallbackContent, style: fallbackStyle };
  };

  // Safely catch dynamic AI DB data or use fallbacks
  const activeItems = content.items || content.faq || content.faqs || [
    { title: 'How does the billing work?', content: 'We offer flexible pricing plans depending on your needs. You can choose to be billed monthly or annually.' },
    { title: 'Can I cancel my subscription anytime?', content: 'Yes, you can cancel your subscription at any time without any hidden fees or penalties.' },
    { title: 'Do you offer a free trial?', content: 'Yes, we offer a 14-day free trial on all our premium plans so you can test the features before committing.' }
  ];

  return (
    <div className="max-w-3xl mx-auto px-6">
      
      {/* HEADER SECTION */}
      <div className="mb-12 text-center">
        <div className="mb-4">
          <ElementsSection 
            isWrapped={false} 
            section={{ ...section, elements: [getEl('title', 'heading', { text: content.title || 'Frequently Asked Questions', htmlTag: 'h2' }, { fontWeight: 'bold' })] }} 
            onElementSelect={onElementSelect} 
            selectedElementId={selectedElementId} 
            onElementUpdate={onElementUpdate || (() => {})} 
            onTextEdit={onTextEdit} 
            readOnly={readOnly} 
            themeColors={themeColors} 
            buttonClass=""
          />
        </div>
        
        {content.subtitle && (
          <div className="opacity-70 max-w-2xl mx-auto">
            <ElementsSection 
              isWrapped={false} 
              section={{ ...section, elements: [getEl('subtitle', 'text', { text: content.subtitle, textSize: 'large' }, {})] }} 
              onElementSelect={onElementSelect} 
              selectedElementId={selectedElementId} 
              onElementUpdate={onElementUpdate || (() => {})} 
              onTextEdit={onTextEdit} 
              readOnly={readOnly} 
              themeColors={themeColors} 
              buttonClass=""
            />
          </div>
        )}
      </div>

      {/* ACCORDION SECTION - Theme colors from start (same as section/card) */}
      <div className="w-full" style={{ backgroundColor: 'transparent' }}>
        <ElementsSection 
          isWrapped={false} 
          section={{ 
            ...section, 
            elements: [getEl('accordion', 'accordion', { 
              items: activeItems.map((item: any) => ({
                ...item,
                style: {
                  ...item.style,
                  borderBottom: `1px solid ${(styles.borderColor || styleAny.cardBorderColor || '#E5E7EB')}20`,
                  paddingTop: '1.5rem',
                  paddingBottom: '1.5rem',
                }
              }))
            }, { 
              accentColor: styles.accentColor || '#3b82f6',
              backgroundColor: styleAny.accordionBackgroundColor || styleAny.cardBackgroundColor || styles.overlayColor || '#FFFFFF',
              borderColor: styleAny.accordionBorderColor || styleAny.cardBorderColor || styles.borderColor || '#E5E7EB',
              titleColor: styleAny.accordionQuestionColor || styles.titleColor || '#111827',
              color: styleAny.accordionAnswerColor || styles.textColor || '#4B5563',
              borderRadius: '12px',
              padding: '20px',
            })] 
          }} 
          onElementSelect={onElementSelect} 
          selectedElementId={selectedElementId} 
          onElementUpdate={onElementUpdate || (() => {})} 
          onTextEdit={onTextEdit} 
          readOnly={readOnly} 
          themeColors={themeColors} 
          buttonClass=""
        />
      </div>
      
    </div>
  );
};
