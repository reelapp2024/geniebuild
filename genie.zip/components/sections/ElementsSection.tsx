
import React, { useState, useEffect, useRef } from 'react';
import { Section, WebsiteElement } from '../../types';
import { useTheme } from '@ui/blocks';
import { ELEMENT_DEFAULTS, PRESET_THEMES } from '../../constants';

interface ElementsSectionProps {
  section: Section;
  onTextEdit: (key: any, value: string) => void;
  onUpload?: (sectionId: string, field: string) => void;
  onElementUpdate: (elementId: string, updates: Partial<WebsiteElement>) => void;
  onElementSelect?: (elementId: string, element?: WebsiteElement) => void;
  selectedElementId?: string | null;
  buttonClass: string;
  readOnly?: boolean;
  isWrapped?: boolean; // If false, renders elements without wrapper div (for use in custom layouts)
  themeColors?: {
    titleColor?: string;
    textColor?: string;
    accordionQuestionColor?: string;
    accordionAnswerColor?: string;
    accordionBackgroundColor?: string;
    accordionBorderColor?: string;
    cardBackgroundColor?: string;
    cardBorderColor?: string;
    accentColor?: string;
    buttonBackgroundColor?: string;
    buttonTextColor?: string;
    backgroundColor?: string;
    // Global style properties for unified styling
    buttonFontWeight?: string;
    buttonFontSize?: string;
    buttonAlign?: string;
    buttonFontFamily?: string;
    titleFontWeight?: string;
    titleFontSize?: string;
    titleAlign?: string;
    titleFontFamily?: string;
    subtitleFontWeight?: string;
    subtitleFontSize?: string;
    subtitleAlign?: string;
    subtitleFontFamily?: string;
    descriptionFontFamily?: string;
    fontWeight?: string;
    fontSize?: string;
    textAlign?: string;
    fontFamily?: string;
  };
}

// Helper for Countdown
const CountdownTimer = ({ targetDate, style }: { targetDate: string, style: any }) => {
    const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

    useEffect(() => {
        const interval = setInterval(() => {
            const now = new Date().getTime();
            const distance = new Date(targetDate).getTime() - now;
            
            if (distance < 0) {
                clearInterval(interval);
            } else {
                setTimeLeft({
                    days: Math.floor(distance / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                    minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
                    seconds: Math.floor((distance % (1000 * 60)) / 1000)
                });
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [targetDate]);

    const boxClass = "flex flex-col items-center p-3 rounded bg-white/5 border border-white/10 min-w-[60px] md:min-w-[80px]";
    const numClass = "text-xl md:text-2xl font-bold";
    const labelClass = "text-[10px] uppercase opacity-60";

    return (
        <div className="flex gap-2 md:gap-4" style={{ justifyContent: style.textAlign === 'center' ? 'center' : (style.textAlign === 'right' ? 'flex-end' : 'flex-start') }}>
            <div className={boxClass} style={{ borderColor: style.accentColor }}>
                <span className={numClass}>{timeLeft.days}</span>
                <span className={labelClass}>Days</span>
            </div>
            <div className={boxClass} style={{ borderColor: style.accentColor }}>
                <span className={numClass}>{timeLeft.hours}</span>
                <span className={labelClass}>Hrs</span>
            </div>
            <div className={boxClass} style={{ borderColor: style.accentColor }}>
                <span className={numClass}>{timeLeft.minutes}</span>
                <span className={labelClass}>Min</span>
            </div>
            <div className={boxClass} style={{ borderColor: style.accentColor }}>
                <span className={numClass}>{timeLeft.seconds}</span>
                <span className={labelClass}>Sec</span>
            </div>
        </div>
    );
};

/** Convert rgb/rgba to hex so card/accordion and all elements use # colors per theme */
const colorToHex = (val: string | undefined): string | undefined => {
  if (!val || typeof val !== 'string' || val.startsWith('#')) return val;
  const m = val.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*[\d.]+)?\s*\)/);
  if (!m) return val;
  const r = Math.max(0, Math.min(255, parseInt(m[1], 10)));
  const g = Math.max(0, Math.min(255, parseInt(m[2], 10)));
  const b = Math.max(0, Math.min(255, parseInt(m[3], 10)));
  return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
};

const getSafeStyle = (style: any): React.CSSProperties => {
  const css: any = { ...style };
  if (css.backgroundColor) css.backgroundColor = colorToHex(css.backgroundColor) || css.backgroundColor;
  if (css.borderColor) css.borderColor = colorToHex(css.borderColor) || css.borderColor;
  
  // Explicitly handle 'margin' object from state
  if (typeof style.margin === 'object' && style.margin !== null) {
      if(style.margin.top) css.marginTop = style.margin.top;
      if(style.margin.right) css.marginRight = style.margin.right;
      if(style.margin.bottom) css.marginBottom = style.margin.bottom;
      if(style.margin.left) css.marginLeft = style.margin.left;
      delete css.margin;
  }
  
  // Explicitly handle 'padding' object from state
  if (typeof style.padding === 'object' && style.padding !== null) {
      if(style.padding.top) css.paddingTop = style.padding.top;
      if(style.padding.right) css.paddingRight = style.padding.right;
      if(style.padding.bottom) css.paddingBottom = style.padding.bottom;
      if(style.padding.left) css.paddingLeft = style.padding.left;
      delete css.padding;
  }
  
  // Remove non-standard CSS properties
  delete css.backgroundGradient;
  delete css.backgroundOverlay;
  delete css.accentColor;
  delete css.hiddenOnDesktop;
  delete css.hiddenOnTablet;
  delete css.hiddenOnMobile;
  
  // Remove fontFamily if it's undefined, null, or empty string (let CSS theme handle it)
  if (!css.fontFamily || css.fontFamily.trim() === '') {
    delete css.fontFamily;
  }

  return css as React.CSSProperties;
};

const getMarqueePxPerSecond = (speed: unknown): number => {
  const pxPerSecondMap: Record<string, number> = {
    '1x': 80,
    '2x': 120,
    '3x': 160,
    '4x': 210,
    '5x': 260,
    '6x': 310,
    '7x': 360,
    '8x': 420,
    '9x': 470,
    '10x': 530,
  };
  return pxPerSecondMap[String(speed)] || 210;
};

const MarqueeTextElement: React.FC<{
  id: string;
  text: string;
  speed: unknown;
  direction: 'left' | 'right';
  readOnly: boolean;
  selectedClass: string;
  textSizeClass: string;
  textStyle: React.CSSProperties;
  safeStyle: React.CSSProperties;
  onClick?: (e: React.MouseEvent) => void;
  onBlurText: (value: string) => void;
}> = ({ id, text, speed, direction, readOnly, selectedClass, textSizeClass, textStyle, safeStyle, onClick, onBlurText }) => {
  const spanRef = useRef<HTMLSpanElement | null>(null);
  const [copyWidth, setCopyWidth] = useState<number>(0);

  useEffect(() => {
    const measure = () => {
      const el = spanRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      if (rect.width > 0) setCopyWidth(rect.width);
    };
    measure();
    const handleResize = () => measure();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [text]);

  const distancePx = Math.max(240, copyWidth); // fallback avoids “stuck” animation on first render
  const pxPerSecond = getMarqueePxPerSecond(speed);
  const durationSeconds = Math.max(2, distancePx / Math.max(60, pxPerSecond));

  const wrapperStyle: React.CSSProperties = {
    margin: (safeStyle as any).margin,
    padding: safeStyle.padding || '6px 16px',
    backgroundColor: (safeStyle as any).backgroundColor || 'rgba(0,0,0,0.35)',
    borderRadius: (safeStyle as any).borderRadius,
    width: (safeStyle as any).width || '100%',
    height: (safeStyle as any).height,
    minHeight: (safeStyle as any).minHeight,
    maxHeight: (safeStyle as any).maxHeight,
    overflow: 'hidden'
  };

  const trackStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    whiteSpace: 'nowrap',
    willChange: 'transform',
    animationName: direction === 'right' ? 'gb-marquee-right' : 'gb-marquee-left',
    animationDuration: `${durationSeconds}s`,
    animationTimingFunction: 'linear',
    animationIterationCount: 'infinite',
    // CSS var used by keyframes for pixel-accurate distance
    ['--gb-marquee-distance' as any]: `${distancePx}px`
  };

  const editableTextStyle: React.CSSProperties = { ...textStyle };

  return (
    <div
      key={`${id}-marquee-${direction}-${String(speed)}`}
      className={`outline-none rounded relative transition-all cursor-pointer ${textSizeClass} ${selectedClass}`}
      style={wrapperStyle}
      onClick={onClick}
    >
      <style>{`
        @keyframes gb-marquee-left {
          0% { transform: translateX(0); }
          100% { transform: translateX(calc(-1 * var(--gb-marquee-distance))); }
        }
        @keyframes gb-marquee-right {
          0% { transform: translateX(calc(-1 * var(--gb-marquee-distance))); }
          100% { transform: translateX(0); }
        }
      `}</style>

      <div
        className="w-max"
        style={trackStyle}
      >
        <span
          ref={spanRef}
          style={editableTextStyle}
          contentEditable={!readOnly}
          suppressContentEditableWarning={!readOnly}
          onBlur={!readOnly ? (e: any) => onBlurText(e.currentTarget.textContent || '') : undefined}
        >
          {text}
        </span>
        <span style={editableTextStyle}>
          {text}
        </span>
      </div>
    </div>
  );
};

export const ElementsSection: React.FC<ElementsSectionProps> = ({ section, onElementUpdate, onElementSelect, selectedElementId, buttonClass, readOnly = false, isWrapped = true, themeColors }) => {
  const elements = section.elements || [];
  const [activeTabs, setActiveTabs] = useState<Record<string, number>>({});
  const { themeData } = useTheme();
  
  // Get theme colors from section styles or passed prop
  // Simplified: Only core colors, let ELEMENT_DEFAULTS handle the rest
  const sectionStyles = (section.styles || {}) as Record<string, unknown>;
  const baseTheme = {
    titleColor: section.styles?.titleColor || themeData?.heading || '#F8FAFC',
    textColor: section.styles?.textColor || themeData?.description || '#D1D5DB',
    backgroundColor: (sectionStyles?.backgroundColor as string) || (themeData as any)?.surface || '',
    accordionQuestionColor:
      (sectionStyles?.accordionQuestionColor as string) ||
      (themeData as any)?.accordion?.questionColor ||
      themeData?.heading ||
      '#F8FAFC',
    accordionAnswerColor:
      (sectionStyles?.accordionAnswerColor as string) ||
      (themeData as any)?.accordion?.answerColor ||
      themeData?.description ||
      '#D1D5DB',
    cardBackgroundColor: (sectionStyles?.cardBackgroundColor as string) || (themeData as any)?.light?.surface || '#FFFFFF',
    cardBorderColor: (sectionStyles?.cardBorderColor as string) || (themeData as any)?.light?.overlay?.color || '#E5E7EB',
    accordionBackgroundColor:
      (sectionStyles?.accordionBackgroundColor as string) ||
      (sectionStyles?.cardBackgroundColor as string) ||
      (themeData as any)?.light?.surface ||
      '#FFFFFF',
    accordionBorderColor:
      (sectionStyles?.accordionBorderColor as string) ||
      (sectionStyles?.cardBorderColor as string) ||
      (themeData as any)?.light?.overlay?.color ||
      '#E5E7EB',
    accentColor: section.styles?.accentColor || themeData?.accent || '#3b82f6',
    buttonBackgroundColor: section.styles?.buttonBackgroundColor || themeData?.primaryButton?.bg || '#E11D48',
    buttonTextColor: section.styles?.buttonTextColor || themeData?.primaryButton?.text || '#FFFFFF',

    // Font fallbacks from global theme typography
    titleFontFamily: (themeData as any)?.typography?.h1?.fontFamily,
    subtitleFontFamily: (themeData as any)?.typography?.h2?.fontFamily,
    descriptionFontFamily: (themeData as any)?.typography?.p?.fontFamily,
    buttonFontFamily: (themeData as any)?.typography?.button?.fontFamily,
  };

  const theme = { ...baseTheme, ...(themeColors || {}) };
  
  // Helper to merge element style with theme defaults
  // Only uses element color if it's explicitly set (not undefined/null/empty)
  const getThemeAwareStyle = (elementStyle: any, colorKey: 'color' | 'backgroundColor' | 'borderColor', themeColor?: string): any => {
    const mergedStyle = { ...elementStyle };
    
    // If element has explicit color, use it; otherwise use theme color
    if (themeColor && (!elementStyle[colorKey] || elementStyle[colorKey] === 'transparent' || elementStyle[colorKey] === '')) {
      mergedStyle[colorKey] = themeColor;
    }
    
    return mergedStyle;
  };

  const handleContentUpdate = (id: string, key: string, value: any) => {
    const el = elements.find(e => e.id === id);
    if(el) {
        onElementUpdate(id, { content: { ...el.content, [key]: value } });
    }
  };

  const handleClick = (e: React.MouseEvent, element: WebsiteElement) => {
      e.stopPropagation();
      if (onElementSelect) {
          onElementSelect(element.id, element);
      }
  };

  const renderElement = (el: WebsiteElement) => {
    const { id, type, content, style } = el;
    const isSelected = selectedElementId === id;
    const selectedClass = isSelected ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-black z-20' : 'hover:ring-1 hover:ring-white/20';

    // STEP 1: Merge Global Element Defaults with Element's specific style
    const renderStyle = {
      ...(ELEMENT_DEFAULTS[el.type] || {}),
      ...(el.style || {})
    };

    let mergedStyle = { ...renderStyle };
    
    // Only pre-fill buttons globally, let individual case blocks handle their specific semantic colors (title, accent, etc.)
    if (theme) {
      if ((type === 'button' || type === 'call-to-action') && (!renderStyle?.backgroundColor || renderStyle.backgroundColor === 'transparent' || renderStyle.backgroundColor === '')) {
        mergedStyle.backgroundColor = theme.buttonBackgroundColor;
        if (!renderStyle?.color || renderStyle.color === 'transparent' || renderStyle.color === '') {
          mergedStyle.color = theme.buttonTextColor;
        }
      }
    }
    
    const safeStyle = getSafeStyle(mergedStyle);

    switch (type) {
        case 'heading':
            const headingTag = (content.htmlTag || 'h2') as 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
            // Style Hierarchy: renderStyle (ELEMENT_DEFAULTS + element.style) > Theme Colors
            const resolvedHeadingFontFamily =
              safeStyle.fontFamily && safeStyle.fontFamily.trim() !== ''
                ? safeStyle.fontFamily
                : theme?.titleFontFamily;
            const headingStyle: React.CSSProperties = {
                ...safeStyle,
                color: safeStyle.color || theme?.titleColor || '#F8FAFC',
                // Fallback to renderStyle (which already contains ELEMENT_DEFAULTS)
                fontWeight: renderStyle.fontWeight || 'bold',
                fontSize: renderStyle.fontSize || undefined,
                textAlign: (renderStyle.textAlign as any) || 'left',
                fontFamily: resolvedHeadingFontFamily && resolvedHeadingFontFamily.trim() !== '' ? resolvedHeadingFontFamily : undefined,
            };
            // Remove undefined properties
            if (!headingStyle.fontFamily) delete headingStyle.fontFamily;
            if (!headingStyle.fontSize) delete headingStyle.fontSize;
            return React.createElement(
                headingTag,
                {
                    key: `${id}-${headingTag}`, // Force re-render when tag changes
                    className: `font-bold outline-none rounded px-1 relative transition-all cursor-pointer ${selectedClass}`,
                    style: headingStyle,
                    onClick: (e: React.MouseEvent) => handleClick(e, el),
                    contentEditable: !readOnly,
                    suppressContentEditableWarning: !readOnly,
                    onBlur: !readOnly ? (e: any) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined
                },
                content.text
            );

        case 'text':
            // Get text size class based on textSize variant
            const textSizeClass = content.textSize === 'small' ? 'text-sm' : 
                                  content.textSize === 'large' ? 'text-lg' : 
                                  content.textSize === 'xl' ? 'text-xl' : '';
            const isSubtitleElement = id.includes('-hero-subtitle');
            // Style Hierarchy: renderStyle (ELEMENT_DEFAULTS + element.style) > Theme Colors
            const resolvedTextFontFamily =
              safeStyle.fontFamily && safeStyle.fontFamily.trim() !== ''
                ? safeStyle.fontFamily
                : isSubtitleElement
                  ? theme?.subtitleFontFamily
                  : theme?.descriptionFontFamily;
            const textStyle: React.CSSProperties = {
                ...safeStyle,
                color: safeStyle.color || theme.textColor || '#D1D5DB',
                // Fallback to renderStyle (which already contains ELEMENT_DEFAULTS)
                fontWeight: renderStyle.fontWeight || '400',
                fontSize: renderStyle.fontSize || undefined,
                textAlign: (renderStyle.textAlign as any) || 'left',
                fontFamily: resolvedTextFontFamily && resolvedTextFontFamily.trim() !== '' ? resolvedTextFontFamily : undefined,
            };
            // Remove undefined properties
            if (!textStyle.fontFamily) delete textStyle.fontFamily;
            if (!textStyle.fontSize) delete textStyle.fontSize;
            if (content.enableMarquee) {
                return (
                    <MarqueeTextElement
                      id={id}
                      text={content.text || ''}
                      speed={content.marqueeSpeed}
                      direction={content.marqueeDirection === 'right' ? 'right' : 'left'}
                      readOnly={readOnly}
                      selectedClass={selectedClass}
                      textSizeClass={textSizeClass}
                      textStyle={textStyle}
                      safeStyle={safeStyle as any}
                      onClick={!readOnly ? (e) => handleClick(e, el) : undefined}
                      onBlurText={(v) => handleContentUpdate(id, 'text', v)}
                    />
                );
            }
            return (
                <p 
                    key={`${id}-${content.textSize || 'base'}`}
                    className={`outline-none rounded px-1 relative transition-all cursor-pointer ${textSizeClass} ${selectedClass}`}
                    style={textStyle}
                    onClick={!readOnly ? (e: React.MouseEvent) => handleClick(e, el) : undefined}
                    contentEditable={!readOnly}
                    suppressContentEditableWarning={!readOnly}
                    onBlur={!readOnly ? (e: any) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}
                >
                    {content.text}
                </p>
            );

        case 'button':
        case 'call-to-action':
            // Style Hierarchy: renderStyle (ELEMENT_DEFAULTS + element.style) > Theme Colors
            const resolvedButtonFontFamily =
              safeStyle.fontFamily && safeStyle.fontFamily.trim() !== ''
                ? safeStyle.fontFamily
                : theme?.buttonFontFamily;
            const buttonStyle: React.CSSProperties = {
                ...safeStyle, // This includes all properties from getSafeStyle
                backgroundColor: safeStyle.backgroundColor || theme?.buttonBackgroundColor || '#E11D48',
                color: safeStyle.color || theme?.buttonTextColor || '#FFFFFF',
                textAlign: 'center' as const, // Button text is always centered internally
                // Fallback to renderStyle (which already contains ELEMENT_DEFAULTS)
                fontWeight: renderStyle.fontWeight || 'bold',
                fontSize: renderStyle.fontSize || undefined,
                fontFamily: resolvedButtonFontFamily && resolvedButtonFontFamily.trim() !== '' ? resolvedButtonFontFamily : undefined,
            };
            // Remove undefined properties
            if (!buttonStyle.fontSize) delete buttonStyle.fontSize;
            if (!buttonStyle.fontFamily) delete buttonStyle.fontFamily;
            const buttonElement = (
                <button 
                    className={`${buttonClass} ${!readOnly ? 'outline-none relative transition-all cursor-pointer' : ''} ${selectedClass}`}
                    style={buttonStyle}
                    onClick={!readOnly ? (e) => handleClick(e, el) : undefined}
                    contentEditable={!readOnly}
                    suppressContentEditableWarning={!readOnly}
                    onBlur={!readOnly ? (e: any) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}
                >
                    {content.text}
                </button>
            );
            
            // Use flexbox with justify-content for proper button alignment
            // Convert textAlign to flexbox justify-content: left -> flex-start, center -> center, right -> flex-end
            const getJustifyContent = (textAlign?: string): 'flex-start' | 'center' | 'flex-end' => {
                if (!textAlign) return 'center';
                switch (textAlign) {
                    case 'left': return 'flex-start';
                    case 'right': return 'flex-end';
                    case 'center': return 'center';
                    case 'justify': return 'center'; // justify doesn't make sense for buttons, default to center
                    default: return 'center';
                }
            };
            
            // CRITICAL: Use display: flex and map element.style.textAlign to justify-content
            // Read textAlign directly from renderStyle (which includes ELEMENT_DEFAULTS)
            const elementTextAlign = (renderStyle?.textAlign as string) || undefined;
            const buttonTextAlign = elementTextAlign || 'center';
            
            return (
                <div 
                    key={id} 
                    style={{ 
                        display: 'flex', 
                        width: '100%', 
                        justifyContent: buttonTextAlign === 'left' ? 'flex-start' : buttonTextAlign === 'right' ? 'flex-end' : 'center' 
                    }}
                >
                    <div>
                        {content.link ? (
                            <a 
                                href={content.link}
                                target={content.link.startsWith('http') ? '_blank' : '_self'}
                                rel={content.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                                onClick={!readOnly ? (e) => {
                                    handleClick(e, el);
                                } : undefined}
                                className="inline-block"
                            >
                                {buttonElement}
                            </a>
                        ) : (
                            buttonElement
                        )}
                        {type === 'call-to-action' && content.subText && (
                            <p className="mt-2 text-sm opacity-70" contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'subText', e.currentTarget.textContent) : undefined}>{content.subText}</p>
                        )}
                    </div>
                </div>
            );

        case 'image':
            const objectFit = (renderStyle?.objectFit || 'cover') as any;
            const objectPosition = (renderStyle?.objectPosition || 'center') as string;
            const overlayColor = (renderStyle as any)?.overlayColor;
            const overlayOpacity = (renderStyle as any)?.overlayOpacity !== undefined ? parseFloat((renderStyle as any).overlayOpacity) : 0;
            
            const imageUrl = content.imageUrl || content.src || '';
            const fullImageUrl = imageUrl 
                ? (imageUrl.startsWith('http') ? imageUrl : `http://localhost:1111${imageUrl.startsWith('/') ? '' : '/'}${imageUrl}`)
                : 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80';
            // 1. Core Outer Style (No hardcoded boxShadow here!)
            const outerStyle: React.CSSProperties = {
                position: 'relative',
                width: renderStyle?.width || '100%',
                aspectRatio: renderStyle?.aspectRatio || 'auto',
                borderRadius: renderStyle?.borderRadius || '0%',
                borderWidth: renderStyle?.borderWidth || '0px',
                borderStyle: renderStyle?.borderStyle || 'none',
                borderColor: renderStyle?.borderColor || 'transparent',
                filter: renderStyle?.filter || 'none',
            };
            // 2. The Professional Shadow & Ring Merger
            // Fallback hierarchy: Element Style -> Theme Default
            let finalBoxShadow = (renderStyle?.boxShadow && renderStyle.boxShadow !== 'none') 
                ? renderStyle.boxShadow 
                : (themeData?.shadow ? `0 4px 6px -1px ${themeData.shadow}, 0 2px 4px -1px ${themeData.shadow}` : undefined);
            
            if (isSelected && !readOnly) {
                // Use themeData.ring for selection ring (like website multicolor theme)
                const ringColor = themeData?.ring || '#3b82f6';
                const ringShadow = `0 0 0 2px #000000, 0 0 0 4px ${ringColor}`;
                // Merge user shadow with selection ring, or just apply ring
                finalBoxShadow = finalBoxShadow ? `${finalBoxShadow}, ${ringShadow}` : ringShadow;
            }
            if (finalBoxShadow) {
                outerStyle.boxShadow = finalBoxShadow;
            }
            // 3. Inner Style (Safely handles clipping)
            const innerStyle: React.CSSProperties = {
                position: 'relative',
                width: '100%',
                height: '100%',
                borderRadius: 'inherit',
                overflow: 'hidden',
            };
            const imgStyle: React.CSSProperties = {
                width: '100%',
                height: '100%',
                objectFit: objectFit,
                objectPosition: objectPosition,
                opacity: renderStyle?.opacity !== undefined ? renderStyle.opacity : 1,
            };
            return (
                <div 
                    key={id}
                    style={outerStyle} 
                    className="group transition-all duration-300"
                    onClick={!readOnly ? (e) => handleClick(e, el) : undefined}
                >
                    <div style={innerStyle}>
                        <img
                            src={fullImageUrl}
                            alt={content.imageAlt || content.altText || content.alt || 'Image'}
                            style={imgStyle}
                            onError={(e) => {
                                // Fallback to placeholder if image fails to load
                                (e.target as HTMLImageElement).src = 'https://via.placeholder.com/600x400';
                            }}
                        />
                        {overlayOpacity > 0 && (
                            <div
                                className="absolute inset-0 pointer-events-none transition-opacity duration-300"
                                style={{
                                    backgroundColor: overlayColor || '#000000',
                                    opacity: overlayOpacity,
                                }}
                            />
                        )}
                    </div>
                </div>
            );

        case 'video':
            // Helper to check if URL is YouTube
            const isYouTubeUrl = (url: string): boolean => {
                return /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/.test(url);
            };
            
            // Helper to convert YouTube URL to embed format
            const convertToEmbedUrl = (url: string): string => {
                if (url.includes('youtube.com/embed/') || url.includes('youtu.be/')) {
                    return url;
                }
                const match = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
                if (match && match[1]) {
                    return `https://www.youtube.com/embed/${match[1]}`;
                }
                return url;
            };
            
            // Construct full video URL
            const videoUrl = content.src || '';
            const fullVideoUrl = videoUrl 
                ? (videoUrl.startsWith('http') 
                    ? (isYouTubeUrl(videoUrl) ? convertToEmbedUrl(videoUrl) : videoUrl)
                    : `http://localhost:1111${videoUrl.startsWith('/') ? '' : '/'}${videoUrl}`)
                : '';
            
            return (
                <div 
                    key={id} 
                    className={`relative w-full aspect-video bg-black rounded-lg overflow-hidden group ${selectedClass}`} 
                    onClick={!readOnly ? (e) => {
                        // Only handle click if not clicking on the overlay
                        if ((e.target as HTMLElement).closest('.video-edit-overlay')) {
                            return;
                        }
                                                handleClick(e, el);
                    } : undefined} 
                    style={safeStyle}
                >
                    {fullVideoUrl ? (
                        <>
                            {isYouTubeUrl(videoUrl) || fullVideoUrl.includes('youtube.com/embed/') ? (
                                <>
                                    <iframe 
                                        src={fullVideoUrl} 
                                        className={`w-full h-full border-0 ${!readOnly ? 'pointer-events-none' : ''}`}
                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                        allowFullScreen
                                    />
                                    {!readOnly && (
                                        <div 
                                            className="video-edit-overlay absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer z-10"
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                handleClick(e, el);
                                            }}
                                            onMouseEnter={(e) => {
                                                e.currentTarget.style.opacity = '1';
                                            }}
                                            onMouseLeave={(e) => {
                                                if (selectedElementId !== id) {
                                                    e.currentTarget.style.opacity = '0';
                                                }
                                            }}
                                            style={{ 
                                                opacity: selectedElementId === id ? 1 : 0 
                                            }}
                                        >
                                            <div className="bg-white text-black px-4 py-2 rounded text-xs font-bold flex items-center gap-2">
                                                <i className="fa-solid fa-edit"></i>
                                                Edit Video
                                            </div>
                                        </div>
                                    )}
                                </>
                            ) : (
                                <>
                                    <video 
                                        src={fullVideoUrl} 
                                        className={`w-full h-full object-contain ${!readOnly ? 'pointer-events-none' : ''}`}
                                        controls={readOnly}
                                        onClick={!readOnly ? (e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            handleClick(e, el);
                                        } : undefined}
                                    />
                                    {!readOnly && (
                                        <div 
                                            className="video-edit-overlay absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer z-10"
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                handleClick(e, el);
                                            }}
                                            onMouseEnter={(e) => {
                                                e.currentTarget.style.opacity = '1';
                                            }}
                                            onMouseLeave={(e) => {
                                                if (selectedElementId !== id) {
                                                    e.currentTarget.style.opacity = '0';
                                                }
                                            }}
                                            style={{ 
                                                opacity: selectedElementId === id ? 1 : 0 
                                            }}
                                        >
                                            <div className="bg-white text-black px-4 py-2 rounded text-xs font-bold flex items-center gap-2">
                                                <i className="fa-solid fa-edit"></i>
                                                Edit Video
                                            </div>
                                        </div>
                                    )}
                                </>
                            )}
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full text-white/20 flex-col gap-4">
                            <i className="fa-solid fa-play text-4xl"></i>
                            <span className="text-sm font-bold uppercase tracking-widest">Add Video URL</span>
                        </div>
                    )}
                </div>
            );

        case 'icon':
            // Ensure icon class is properly formatted (handle both 'fa-star' and 'star' formats)
            const iconClass = content.icon 
                ? (content.icon.startsWith('fa-') ? `fa-solid ${content.icon}` : `fa-solid fa-${content.icon}`)
                : 'fa-solid fa-star';
            // Use theme accentColor if element color is not explicitly set
            const iconColor = safeStyle.color || renderStyle?.accentColor || theme?.accentColor || '#F59E0B';
            return (
                <div key={id} className={`inline-block ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={safeStyle}>
                    <i className={iconClass} style={{ fontSize: content.iconSize || safeStyle.fontSize || '2rem', color: iconColor }}></i>
                </div>
            );
            
        case 'icon-box':
            // Ensure icon class is properly formatted
            const iconBoxClass = content.icon 
                ? (content.icon.startsWith('fa-') ? `fa-solid ${content.icon}` : `fa-solid fa-${content.icon}`)
                : 'fa-solid fa-layer-group';
            // Use theme accentColor if element color is not explicitly set
            const iconBoxColor = renderStyle?.accentColor || theme?.accentColor || '#F59E0B';
            return (
                <div key={id} className={`flex gap-4 p-4 rounded-lg bg-white/5 border border-white/5 ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={safeStyle}>
                    <div className="shrink-0">
                         <i className={iconBoxClass} style={{ fontSize: '2rem', color: iconBoxColor }}></i>
                    </div>
                    <div>
                        <h3 className="font-bold text-lg mb-1" style={{ color: theme?.titleColor || safeStyle.color }} contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}>{content.text || 'Icon Box Title'}</h3>
                        <p className="opacity-70 text-sm" style={{ color: theme?.textColor || safeStyle.color }} contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'subText', e.currentTarget.textContent) : undefined}>{content.subText || 'Description for this icon box goes here.'}</p>
                    </div>
                </div>
            );

        case 'image-box':
            // Construct full image URL for image-box
            const imageBoxUrl = content.imageUrl || content.src || '';
            const fullImageBoxUrl = imageBoxUrl 
                ? (imageBoxUrl.startsWith('http') ? imageBoxUrl : `http://localhost:1111${imageBoxUrl.startsWith('/') ? '' : '/'}${imageBoxUrl}`)
                : 'https://via.placeholder.com/400x250';
            
            return (
                <div key={id} className={`flex flex-col gap-4 p-0 rounded-lg overflow-hidden bg-white/5 border border-white/5 ${selectedClass}`} onClick={!readOnly ? (e) => handleClick(e, el) : undefined} style={safeStyle}>
                     <img 
                        src={fullImageBoxUrl} 
                        className="w-full h-48 object-cover" 
                        alt={content.title || content.text || 'Image Box'} 
                        onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://via.placeholder.com/400x250';
                        }}
                     />
                     <div className="p-6 pt-2">
                        <h3 className="font-bold text-xl mb-2" style={{ color: theme?.titleColor || safeStyle.color }} contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}>{content.title || content.text || 'Image Box Title'}</h3>
                        <p className="opacity-70 text-sm" style={{ color: theme?.textColor || safeStyle.color }} contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'description', e.currentTarget.textContent) : undefined}>{content.description || content.subText || 'Description text for the image box element.'}</p>
                     </div>
                </div>
            );

        case 'list':
            // Use theme textColor if element color is not explicitly set
            const listStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            return (
                <ul key={id} className={`list-disc list-inside space-y-2 ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={listStyle}>
                    {(content.items || [{title: 'List Item 1'}, {title: 'List Item 2'}, {title: 'List Item 3'}]).map((item, i) => (
                        <li key={i} className="opacity-90">
                            {item.title}
                        </li>
                    ))}
                </ul>
            );

        case 'star-rating':
            const rating = content.rating !== undefined ? parseFloat(String(content.rating)) : 5;
            const maxRating = content.maxRating !== undefined ? parseInt(String(content.maxRating)) : 5;
            const starColor = safeStyle.color || theme?.accentColor || '#F59E0B';
            const inactiveColor = 'rgba(255, 255, 255, 0.2)'; // Faded background star
            
            return (
                <div key={id} className={`flex gap-1 ${selectedClass}`} onClick={!readOnly ? (e) => handleClick(e, el) : undefined} style={{ ...safeStyle, color: undefined }}>
                    {Array.from({ length: maxRating }, (_, i) => i + 1).map(star => {
                        const isFull = rating >= star;
                        const isHalf = !isFull && rating >= star - 0.5;
                        
                        return (
                            <div key={star} className="relative inline-block leading-none">
                                {/* Always render inactive background star */}
                                <i className="fa-solid fa-star" style={{ color: inactiveColor }}></i>
                                
                                {/* Render colored foreground star (Full or Half) over it */}
                                {(isFull || isHalf) && (
                                    <i 
                                        className={`fa-solid ${isFull ? 'fa-star' : 'fa-star-half-stroke'} absolute top-0 left-0`}
                                        style={{ color: starColor }}
                                    ></i>
                                )}
                            </div>
                        );
                    })}
                </div>
            );
            
        case 'badge':
            // 1. Get LIVE theme badge colors (Bypassing stale ThemeProvider context)
            const getLiveBadgeColors = () => {
                const liveSurface = (theme as Record<string, string>)?.backgroundColor || (sectionStyles?.backgroundColor as string) || '';
                const preset = PRESET_THEMES.find(t => t.elements.surface.toLowerCase() === liveSurface.toLowerCase());
                if (preset) return { bg: preset.elements.badge.background, text: preset.elements.badge.text };
                
                const hex = theme?.buttonBackgroundColor || '#3b82f6';
                let r = 59, g = 130, b = 246;
                if (hex.startsWith('#') && hex.length === 7) {
                    r = parseInt(hex.slice(1, 3), 16) || r; g = parseInt(hex.slice(3, 5), 16) || g; b = parseInt(hex.slice(5, 7), 16) || b;
                }
                return { bg: `rgba(${r}, ${g}, ${b}, 0.15)`, text: theme?.buttonTextColor || '#FFFFFF' };
            };
            const liveBadge = getLiveBadgeColors();
            const currentThemeBg = liveBadge.bg;
            const currentThemeText = liveBadge.text;
            
            // 2. Safely extract element style
            const elementStyle = el.style || {};
            const rawBg = elementStyle.backgroundColor || elementStyle.accentColor || '';
            const rawText = elementStyle.color || '';

            // 3. Helper to clean duplicated color strings (e.g., "#HEX,#HEX" or "rgba(...),rgba(...)")
            const sanitizeColor = (colorStr: string) => {
                if (!colorStr) return '';
                // Fix duplicated rgba: "rgba(255,0,0,0.5),rgba(255,0,0,0.5)"
                if (colorStr.includes('),rgba')) {
                    return colorStr.split('),rgba')[0] + ')';
                }
                // Fix duplicated hex: "#F8FAFC,#F8FAFC"
                if (colorStr.includes('#') && colorStr.indexOf('#', 1) !== -1) {
                    return colorStr.substring(0, colorStr.indexOf('#', 1)).replace(/,$/, '');
                }
                return colorStr;
            };

            const cleanElementBg = sanitizeColor(rawBg);
            const cleanElementText = sanitizeColor(rawText);

            // 4. Build a list of ALL known preset theme colors to detect remnants of previous themes
            const knownThemeBgs = PRESET_THEMES.map(t => t.elements.badge?.background).filter(Boolean) as string[];
            knownThemeBgs.push('#ec4899', '#F59E0B', 'rgba(225,29,72,0.15)', 'transparent');

            const knownThemeTexts = PRESET_THEMES.map(t => t.elements.badge?.text).filter(Boolean) as string[];
            knownThemeTexts.push('#F8FAFC', '#FFFFFF', '#D1D5DB', 'transparent');

            // 5. Determine if it's a TRUE custom color
            // It is custom ONLY if it exists AND it does not match ANY of our known theme colors
            const isCustomBg = cleanElementBg !== '' && 
                !knownThemeBgs.some(bg => bg.replace(/\s/g, '') === cleanElementBg.replace(/\s/g, ''));
                               
            const isCustomText = cleanElementText !== '' && 
                !knownThemeTexts.some(text => text.replace(/\s/g, '') === cleanElementText.replace(/\s/g, ''));

            // 6. Resolve final colors: Use custom if it exists, otherwise strictly force the current theme
            const badgeBgColor = isCustomBg ? cleanElementBg : currentThemeBg;
            const badgeTextColor = isCustomText ? cleanElementText : currentThemeText;
            
            // 7. Badge size and padding
            const badgeFontSize = renderStyle?.fontSize || '0.75rem';
            const badgePadding = renderStyle?.padding || '6px';
            const badgeBorderRadius = renderStyle?.borderRadius || '9999px';
            
            // 8. Create safe style object excluding colors
            const badgeSafeStyle = { ...safeStyle };
            delete badgeSafeStyle.backgroundColor;
            delete badgeSafeStyle.color;
            
            return (
                <span 
                    key={id} 
                    className={`inline-flex items-center font-medium ${selectedClass}`} 
                    style={{ 
                        backgroundColor: badgeBgColor, 
                        color: badgeTextColor, 
                        fontSize: badgeFontSize,
                        padding: badgePadding,
                        borderRadius: badgeBorderRadius,
                        ...badgeSafeStyle 
                    }}
                    onClick={!readOnly ? (e) => handleClick(e, el) : undefined}
                    contentEditable={!readOnly}
                    suppressContentEditableWarning={!readOnly}
                    onBlur={!readOnly ? (e) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}
                >
                    {content.text || 'Badge'}
                </span>
            );

        case 'highlight-text':
            // Use theme accentColor if element backgroundColor is not explicitly set
            const highlightBgColor = renderStyle?.accentColor || theme?.accentColor || '#facc15';
            const highlightTextStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            return (
                <p key={id} className={`${selectedClass}`} style={highlightTextStyle} onClick={!readOnly ? (e) => handleClick(e, el) : undefined}>
                    Here is some <span className="px-1 rounded" style={{ backgroundColor: highlightBgColor, color: '#000' }}>{content.text || 'Highlighted'}</span> text example.
                </p>
            );

        case 'blockquote':
            // Use theme accentColor and textColor if element colors are not explicitly set
            const blockquoteBorderColor = renderStyle?.borderColor || renderStyle?.accentColor || theme?.accentColor || '#fff';
            const blockquoteStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB',
                borderColor: blockquoteBorderColor
            };
            return (
                <blockquote key={id} className={`border-l-4 pl-4 py-2 italic opacity-80 ${selectedClass}`} style={blockquoteStyle} onClick={!readOnly ? (e) => handleClick(e, el) : undefined}>
                    <p className="mb-2" contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}>"{content.text || 'This is a quote.'}"</p>
                    <cite className="text-sm font-bold not-italic opacity-70">- {content.author || 'Author Name'}</cite>
                </blockquote>
            );

        case 'accordion':
            // Wrapper: no background/border — only each <details> gets its own card-like styling
            const accordionWrapperStyle = { color: safeStyle.color || theme?.textColor || '#D1D5DB' };
            const items = content.items && content.items.length > 0 ? content.items : [
                { title: 'Sample Question 1', content: 'Sample answer 1.' },
                { title: 'Sample Question 2', content: 'Sample answer 2.' }
            ];
            return (
                <div key={id} className={`space-y-3 w-full ${selectedClass}`} onClick={!readOnly ? (e) => handleClick(e, el) : undefined} style={accordionWrapperStyle}>
                    {items.map((item: any, idx: number) => (
                        <details
                            key={idx}
                            className="group border transition-colors w-full overflow-hidden"
                            style={{
                                backgroundColor: (safeStyle.backgroundColor && safeStyle.backgroundColor !== 'transparent') ? safeStyle.backgroundColor : (theme?.accordionBackgroundColor || theme?.cardBackgroundColor || '#FFFFFF'),
                                borderColor: (safeStyle.borderColor && safeStyle.borderColor !== 'transparent') ? safeStyle.borderColor : (theme?.accordionBorderColor || theme?.cardBorderColor || '#E5E7EB'),
                                borderRadius: safeStyle.borderRadius || '0.75rem'
                            }}
                        >
                            <summary
                                className="flex items-center justify-between cursor-pointer list-none select-none"
                                style={{ padding: safeStyle.padding || '1.25rem' }}
                            >
                                <span className="font-bold text-lg" style={{ color: (safeStyle as Record<string, string>).titleColor || theme?.accordionQuestionColor || theme?.titleColor || safeStyle.color || '#F8FAFC' }}>
                                    {item.title || item.question}
                                </span>
                                <div className="shrink-0 w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-open:rotate-180 transition-transform">
                                    <i className="fa-solid fa-chevron-down text-sm" style={{ color: theme?.accentColor || '#3b82f6' }}></i>
                                </div>
                            </summary>
                            <div
                                className="text-base opacity-80 leading-relaxed border-t mt-2"
                                style={{
                                    padding: safeStyle.padding || '1.25rem',
                                    borderColor: theme?.accordionBorderColor || theme?.cardBorderColor || '#E5E7EB',
                                    color: safeStyle.color ?? theme?.accordionAnswerColor ?? theme?.textColor ?? '#D1D5DB'
                                }}
                            >
                                {item.content || item.answer}
                            </div>
                        </details>
                    ))}
                </div>
            );

        case 'toggle':
            // Use theme textColor if element color is not explicitly set
            const toggleStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            return (
                <div key={id} className={`bg-white/5 border border-white/10 rounded-lg ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={toggleStyle}>
                     <details className="group">
                        <summary className="flex items-center gap-3 p-4 cursor-pointer font-bold list-none" style={{ color: theme?.titleColor }}>
                             <div className="w-10 h-6 bg-white/10 rounded-full relative group-open:bg-green-500 transition-colors">
                                 <div className="absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-all group-open:left-5"></div>
                             </div>
                             <span>{content.text || 'Toggle Title'}</span>
                        </summary>
                        <div className="p-4 pt-0 text-sm opacity-80">
                            {content.subText || 'Toggle Content goes here...'}
                        </div>
                     </details>
                </div>
            );

        case 'tabs':
            const currentTab = activeTabs[id] || 0;
            // Use theme accentColor and textColor if element colors are not explicitly set
            const tabsAccentColor = renderStyle?.accentColor || theme?.accentColor || '#3b82f6';
            const tabsStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            return (
                <div key={id} className={`${selectedClass}`} onClick={(e) => handleClick(e, el)} style={tabsStyle}>
                    <div className="flex border-b border-white/10 mb-4 overflow-x-auto">
                        {content.items?.map((item, idx) => (
                            <button 
                                key={idx}
                                onClick={(e) => { e.stopPropagation(); setActiveTabs({...activeTabs, [id]: idx}); }}
                                className={`px-4 py-2 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${currentTab === idx ? 'border-blue-500 text-white' : 'border-transparent text-white/50 hover:text-white'}`}
                                style={{ borderColor: currentTab === idx ? tabsAccentColor : 'transparent' }}
                            >
                                {item.title}
                            </button>
                        ))}
                    </div>
                    <div className="p-4 bg-white/5 rounded-lg border border-white/10 min-h-[100px]">
                        {content.items?.[currentTab]?.content}
                    </div>
                </div>
            );

        case 'progress-bar':
            // Use theme accentColor and textColor if element colors are not explicitly set
            const progressBarColor = renderStyle?.accentColor || theme?.accentColor || '#3b82f6';
            const progressBarStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            return (
                <div key={id} className={`${selectedClass}`} onClick={(e) => handleClick(e, el)} style={progressBarStyle}>
                    <div className="flex justify-between mb-1 text-xs font-bold uppercase tracking-wider">
                        <span>{content.text}</span>
                        <span>{content.percentage}%</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2.5">
                        <div 
                            className="bg-blue-600 h-2.5 rounded-full transition-all duration-1000" 
                            style={{ width: `${content.percentage}%`, backgroundColor: progressBarColor }}
                        ></div>
                    </div>
                </div>
            );

        case 'counter':
            // Use theme accentColor and textColor if element colors are not explicitly set
            const counterAccentColor = renderStyle?.accentColor || theme?.accentColor || '#ffffff';
            const counterStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            return (
                <div key={id} className={`text-center p-6 border border-white/10 bg-white/5 rounded-xl ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={counterStyle}>
                    <div className="text-4xl md:text-5xl font-bold mb-2" style={{ color: counterAccentColor }}>
                        {content.prefix}{content.targetNumber}{content.suffix}
                    </div>
                    <div className="text-sm font-bold uppercase tracking-widest opacity-60">
                        {content.text}
                    </div>
                </div>
            );
        
        case 'alert-box':
            const alertColors = {
                success: 'rgba(34, 197, 94, 0.1)',
                warning: 'rgba(234, 179, 8, 0.1)',
                error: 'rgba(239, 68, 68, 0.1)',
                info: 'rgba(59, 130, 246, 0.1)'
            };
            const alertBorder = {
                success: '#22c55e',
                warning: '#eab308',
                error: '#ef4444',
                info: '#3b82f6'
            };
            const alertBoxType = content.alertType || 'info';
            
            return (
                <div key={id} className={`p-4 rounded-lg border-l-4 flex gap-4 ${selectedClass}`} onClick={(e) => handleClick(e, el)} 
                    style={{ 
                        backgroundColor: alertColors[alertBoxType],
                        borderColor: alertBorder[alertBoxType],
                        ...safeStyle
                    }}
                >
                     <div style={{ color: alertBorder[alertBoxType] }}><i className={`fa-solid ${content.icon || 'fa-circle-info'}`}></i></div>
                     <div>
                         <strong className="block font-bold mb-1" contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'text', e.currentTarget.textContent) : undefined}>{content.text || 'Alert Title'}</strong>
                         <p className="text-sm opacity-80" contentEditable={!readOnly} suppressContentEditableWarning={!readOnly} onBlur={!readOnly ? (e) => handleContentUpdate(id, 'subText', e.currentTarget.textContent) : undefined}>{content.subText || 'Alert description.'}</p>
                     </div>
                </div>
            );

        case 'testimonial':
            // Use theme textColor if element color is not explicitly set
            const testimonialStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
            const testimonialItems = content.items || [{ author: 'John Doe', role: 'Customer', content: 'Great service!', avatar: 'https://via.placeholder.com/50' }];
            return (
                <div key={id} className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full ${selectedClass}`} onClick={(e) => handleClick(e, el)}>
                    {testimonialItems.map((item: any, idx: number) => (
                        <div key={idx} className="p-6 rounded-xl bg-white/5 border border-white/10 flex flex-col h-full" style={testimonialStyle}>
                            <div className="flex items-center gap-4 mb-4">
                                <img src={item.avatar || 'https://via.placeholder.com/50'} className="w-12 h-12 rounded-full object-cover" alt="Avatar" referrerPolicy="no-referrer" />
                                <div>
                                    <div className="font-bold" style={{ color: theme?.titleColor }}>{item.author || 'John Doe'}</div>
                                    <div className="text-xs opacity-50" style={{ color: theme?.textColor }}>{item.role || 'Customer'}</div>
                                </div>
                                <div className="ml-auto text-yellow-500 text-sm">
                                    <i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i>
                                </div>
                            </div>
                            <p className="italic opacity-80 flex-grow" style={{ color: theme?.textColor }}>"{item.content || 'Great service!'}"</p>
                        </div>
                    ))}
                </div>
            );

        case 'logo-cloud':
            const logos = content.items || [];
            return (
                <div key={id} className={`flex flex-wrap items-center justify-center gap-8 md:gap-12 py-8 ${selectedClass}`} onClick={(e) => handleClick(e, el)}>
                    {logos.map((logo: any, idx: number) => (
                        <img 
                            key={idx} 
                            src={logo.src} 
                            alt={logo.alt || 'Logo'} 
                            className="h-8 md:h-10 w-auto grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-300" 
                            referrerPolicy="no-referrer"
                        />
                    ))}
                </div>
            );

        case 'stat-card':
            return (
                <div
                    key={id}
                    className={`p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 group ${selectedClass}`}
                    onClick={(e) => handleClick(e, el)}
                    style={style as React.CSSProperties}
                >
                    <div className="flex items-center gap-4 mb-3">
                        {content.icon && (
                            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                                <i className={`fa-solid fa-${content.icon} text-lg`}></i>
                            </div>
                        )}
                        <div className="text-3xl font-bold tracking-tight" style={{ color: theme?.titleColor }}>{content.value || content.targetNumber || '0'}</div>
                    </div>
                    <div className="text-sm font-semibold uppercase tracking-wider opacity-60 mb-1" style={{ color: theme?.textColor }}>{content.text || 'Label'}</div>
                    {content.subText && <div className="text-xs opacity-40 leading-relaxed" style={{ color: theme?.textColor }}>{content.subText}</div>}
                </div>
            );

        case 'user-avatars':
            const avatars = content.items || [];
            return (
                <div key={id} className={`flex items-center ${selectedClass}`} onClick={(e) => handleClick(e, el)}>
                    <div className="flex -space-x-3 overflow-hidden mr-4">
                        {avatars.map((avatar: any, idx: number) => (
                            <img 
                                key={idx} 
                                className="inline-block h-10 w-10 rounded-full ring-2 ring-[#0F172A] object-cover" 
                                src={avatar.src} 
                                alt={`User ${idx + 1}`} 
                                referrerPolicy="no-referrer"
                            />
                        ))}
                    </div>
                    {content.targetNumber && (
                        <div className="text-sm font-medium" style={{ color: theme?.textColor }}>
                            Join <span className="text-blue-400 font-bold">{content.targetNumber}</span> others
                        </div>
                    )}
                </div>
            );

        case 'pricing-table':
            // Use theme accentColor and textColor if element colors are not explicitly set
            const pricingBorderColor = renderStyle?.borderColor || renderStyle?.accentColor || theme?.accentColor || '#3b82f6';
            const pricingStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB',
                borderColor: pricingBorderColor
            };
             return (
                 <div key={id} className={`p-8 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center text-center ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={pricingStyle}>
                     <h3 className="text-xl font-bold mb-2" style={{ color: theme?.titleColor }}>{content.text || 'Plan Name'}</h3>
                     <div className="text-4xl font-bold mb-1" style={{ color: theme?.accentColor }}>{content.price || '$99'}</div>
                     <div className="text-sm opacity-50 mb-6">{content.period || 'per month'}</div>
                     <ul className="space-y-3 mb-8 w-full text-left">
                         {content.items?.map((feature, i) => (
                             <li key={i} className="flex gap-2 text-sm opacity-80">
                                 <i className="fa-solid fa-check text-green-500 mt-1"></i> {feature.title}
                             </li>
                         ))}
                     </ul>
                     <button className={`${buttonClass} w-full`}>{content.link || 'Choose Plan'}</button>
                 </div>
             );

        case 'flip-box':
            const directionClass = {
                left: 'group-hover:rotate-y-180',
                right: 'group-hover:-rotate-y-180',
                top: 'group-hover:rotate-x-180',
                bottom: 'group-hover:-rotate-x-180'
            };
            const dir = content.flipDirection || 'left';
            const rotateClass = directionClass[dir] || directionClass.left;
            
            const backRotate = (dir === 'top' || dir === 'bottom') ? 'rotate-x-180' : 'rotate-y-180';
            
            // Use theme accentColor if element color is not explicitly set
            const flipBoxAccentColor = renderStyle?.accentColor || theme?.accentColor || '#3b82f6';
            const flipBoxStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };

            return (
                 <div key={id} className={`group h-64 perspective-1000 ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={flipBoxStyle}>
                     <div className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${rotateClass}`}>
                         <div className="absolute inset-0 backface-hidden bg-white/10 border border-white/10 rounded-xl flex flex-col items-center justify-center p-6 text-center">
                              <i className={`fa-solid ${content.icon || 'fa-star'} text-4xl mb-4`} style={{color: flipBoxAccentColor}}></i>
                              <h3 className="font-bold text-xl" style={{ color: theme?.titleColor }}>{content.frontTitle || 'Front Title'}</h3>
                              <p className="text-sm opacity-70 mt-2">{content.frontDesc || 'Hover to flip'}</p>
                         </div>
                         <div className={`absolute inset-0 backface-hidden ${backRotate} bg-blue-600 rounded-xl flex flex-col items-center justify-center p-6 text-center`} style={{ backgroundColor: flipBoxAccentColor }}>
                              <h3 className="font-bold text-xl">{content.backTitle || 'Back Title'}</h3>
                              <p className="text-sm opacity-90 mt-2 mb-4">{content.backDesc || 'Hidden details revealed.'}</p>
                              <button className="px-4 py-2 bg-white text-black text-xs font-bold rounded-full">Action</button>
                         </div>
                     </div>
                 </div>
            );

        case 'countdown-timer':
            // Use theme accentColor and textColor if element colors are not explicitly set
            const countdownAccentColor = renderStyle?.accentColor || theme?.accentColor || '#F59E0B';
            const countdownStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || '#D1D5DB'
            };
             return (
                 <div key={id} className={`${selectedClass}`} onClick={(e) => handleClick(e, el)} style={countdownStyle}>
                     <h4 className="font-bold mb-4 uppercase tracking-widest text-xs opacity-50" style={{textAlign: safeStyle.textAlign}}>{content.text || 'Offer Ends In'}</h4>
                     <CountdownTimer targetDate={content.targetDate || new Date(Date.now() + 86400000).toISOString()} style={{ ...style, accentColor: countdownAccentColor }} />
                 </div>
             );

        case 'review-carousel':
            // Use theme textColor if element color is not explicitly set
            // Fallback hierarchy: Element Style -> Section Style -> Theme Default
            const reviewCarouselStyle = {
                ...safeStyle,
                color: safeStyle.color || theme?.textColor || themeData?.description || '#D1D5DB'
            };
            // Use themeData.trust for author name (like website multicolor theme)
            const authorColor = theme?.titleColor || themeData?.heading || '#F8FAFC';
            const reviewTextColor = themeData?.description || theme?.textColor || '#D1D5DB';
            return (
                 <div key={id} className={`p-6 bg-white/5 border border-white/10 rounded-xl ${selectedClass}`} onClick={(e) => handleClick(e, el)} style={reviewCarouselStyle}>
                     <div className="flex gap-4 overflow-hidden mask-linear-gradient">
                         {(content.items || [{title: 'Review 1'}, {title: 'Review 2'}]).map((item, i) => (
                             <div key={i} className="min-w-[250px] p-4 bg-black/20 rounded border border-white/5">
                                 <div className="text-yellow-500 text-xs mb-2"><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i></div>
                                 <p className="text-sm italic opacity-80 mb-2" style={{ color: reviewTextColor }}>"{item.content || 'Excellent product.'}"</p>
                                 <div className="font-bold text-xs" style={{ color: authorColor }}>{item.author || 'User'}</div>
                             </div>
                         ))}
                     </div>
                 </div>
            );

        default:
             return (
                 <div key={id} className={`${selectedClass} opacity-50`} onClick={(e) => handleClick(e, el)}>
                     Element {type} not fully implemented in preview.
                 </div>
             );
    }
  };

  // Render elements
  // When isWrapped is false, render elements directly without grid wrapper (for custom layouts)
  // When isWrapped is true, wrap in grid for standard sections
  const elementsContent = isWrapped ? (
    <div className="grid gap-8">
      {elements.map(renderElement)}
    </div>
  ) : (
    <>
      {elements.map(renderElement)}
    </>
  );

  // If isWrapped is false, render elements directly without wrapper (for use in custom layouts)
  if (!isWrapped) {
    return elementsContent;
  }

  // Default: render with wrapper div for standard sections
  return (
    <div className="max-w-6xl mx-auto px-6 py-4 relative z-10 text-left">
      {elementsContent}
    </div>
  );
};
